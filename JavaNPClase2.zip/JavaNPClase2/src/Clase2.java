
public class Clase2 {

	public static void main(String[] args) {
		// Clase 2

		int nro1 = 5;
		int nro2 = 7;
		boolean log1 = true;
		boolean log2 = false;

		// Operador de asignación =

		System.out.println(nro1 + " " + nro2);

		nro1 = nro2;
		// <---

		System.out.println(nro1 + " " + nro2);

		// Constantes
		final double PI = 3.14;
		// PI=3; //error

		// Operadores incrementales

		System.out.println(nro1);
		// Sumar 1 a la variable nro1 ++
		nro1++; // nro1=nro1+1;
		System.out.println(nro1);

		// Restar 1 a la variable nro1 --
		nro1--; // nro1=nro1-1;
		System.out.println(nro1);

		// sumar 5 a la variable nro1 +=
		nro1 += 5; // nro1=nro1+5;
		System.out.println(nro1);

		// restar 5 a la variable nro1 -=
		nro1 -= 5; // nro1=nro1-5;
		System.out.println(nro1);

		// multiplicar la variable *=
		nro1 *= 5; // nro1=nro1*5;
		System.out.println(nro1);

		// Dividir la variable /=
		nro1 /= 5; // nro1=nro1/5;
		System.out.println(nro1);

		// Precedencia y procedencia de operadores unarios ++ --
		System.out.println(nro1); // 7
		System.out.println(nro1++); // 7
		System.out.println(nro1); // 8
		System.out.println(++nro1); // 9

		/*
		 * Operadores Logicos
		 * 
		 * Operador Nombre == equals (comparación) != not equals (distinto) ! not
		 * (negación) < <= >= > comparadores
		 * 
		 * && and y (shift 6) || or o (altgr 1)
		 * 
		 */

		System.out.println(nro1 + " " + nro2);
		System.out.println(nro1 == nro2);
		System.out.println(nro1 == 9);
		System.out.println(nro1 != nro2);
		System.out.println(nro1 != 9);
		System.out.println(nro1 >= nro2);
		System.out.println(nro1 <= nro2);

		System.out.println(log1); // true
		System.out.println(!log1); // false
		System.out.println(!!log1); // true
		System.out.println(!!!log1); // false
		System.out.println(!!!!log1); // true

		log1 = !log1; // false
		System.out.println(log1); // false

		/*
		 * Tabla de verdad
		 * 
		 * X Y OR AND F F F F F V V F V F V F V V V V
		 * 
		 */

		log1 = true;
		log2 = false;

		System.out.println(log1 || log2); // true
		System.out.println(log1 && log2); // false

		System.out.println(nro1 == 9 && !log2);

		// Operadores binarios | &
		System.out.println(log1 | log2); // true
		System.out.println(log1 & log2); // false

		System.out.println(log1 || (nro1 + 2 == nro2 + 4)); // true
		System.out.println(log1 | (nro1 + 2 == nro2 + 4)); // true

		System.out.println(	
				!!log2 || 
				!!!log1 || 
				nro1 + 2 > nro2 + 4 || 
				(nro1 - 4 != nro2 - 3 && nro1 > nro2 + 1 && !log2)
		);

		// Estructura condicional if
		if (log1) {
			System.out.println("Verdad 1");
		}

		if (log1 == true) {
			System.out.println("Verdad 2");
			// Código esta indentado
		}

		//Uso de llaves modo microsoft
		if(!log1) 
		{
			System.out.println("Verdad 3");
		}
		
		//Uso de llaves abreviado
		if(!log1) System.out.println("Verdad 4");
		
		
		//Estructura if else
		if(!log1) {
			System.out.println("Verdad 5");
		}else {
			System.out.println("False 5");
		}
		
		//Uso de llaves Modo microsoft
		if(log1)
		{
			System.out.println("Verdad 6");
		}
		else
		{
			System.out.println("Falso 6");
		}
		
		//modo abreviado de llaves
		if(log1) 	System.out.println("Verdad 7");
		else 		System.out.println("Falso 7");	
		
		
	}

}
