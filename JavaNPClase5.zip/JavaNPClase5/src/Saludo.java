public class Saludo{
	public static void main(String[] args){
		if(args.length==0) 	System.out.println("\033[31mDebe ingresar su nombre como parametro!\u001B[0m");
		else 				System.out.println("\033[32mHola "+args[0]+"\u001B[0m");
	}
}
