public class Sumar{
	public static void main(String[] args){
		if(args.length!=2){
			System.out.println("\033[31mDebe ingresar dos números como parametro!\u001B[0m");
		} else {
			int nro1=Integer.parseInt(args[0]);
			int nro2=Integer.parseInt(args[1]);
			int suma=nro1+nro2;
			System.out.println("\033[32mSuma: "+suma+"\u001B[0m");
		}
	}
}
