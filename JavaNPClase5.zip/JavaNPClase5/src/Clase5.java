import java.time.LocalDate;

public class Clase5 {

	public static void main(String[] args) {
		// Clase 5 - Arrays - Vectores
		
		//Declarar Arrays
		int[] numeros = new int[4];
		String[] nombres = new String[4];
		
		//cargar valores en los Arrays
		numeros[0]=1;
		nombres[0]="Juan";
		numeros[1]=2;
		nombres[1]="Ana";
		numeros[2]=3;
		nombres[2]="Javier";
		numeros[3]=4;
		nombres[3]="Laura";
		
		//Error
		//numeros[4]=5;
		//nombres[4]="Mirta";
		//numeros[-1]=-1;
		//nombres[-1]="Karina";
		
		//Sobreescribir un valor del Array
		//nombres[2]="Matias";
		
		//Imprimir una posición del Array
		System.out.println(numeros[2]+" "+nombres[2]);
		
		/*
		 * 		indice	numeros		nombres
		 * 			0		_1		Juan___
		 * 			1		_2		Ana____
		 * 			2		_3		Javier_
		 * 			3		_4		Laura__
		 */
		
		System.out.println("************************************************************");
		//Recorrer e imprimir todo el Array
		for(int a=0; a<4; a++) System.out.println(numeros[a]+" "+nombres[a]);
		
		//Atributo(Método) lenght
		System.out.println("Longitud de vector numeros: "+numeros.length);
		
		//Recorrido usando length
		for(int a=0; a<numeros.length; a++) System.out.println(numeros[a]+" "+nombres[a]); 

		System.out.println("************************************************************");
		//Recorrido usando While
		int x=0;
		while(x<numeros.length) {
			System.out.println(numeros[x]+" "+nombres[x]);
			x++;
		}
		
		System.out.println("************************************************************");
		//Recorrido inverso
		for(int a=numeros.length-1; a>=0; a--) System.out.println(numeros[a]+" "+nombres[a]);
		
		
		//Definición abreviada
		String[] semana= {"Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"};
		String[] meses= {"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
		int[] vector= {23,26,24,39,38,65,22,29,14,17,15,27,28};
		
		System.out.println("Longitud Vector semana: "+semana.length);
		for(int a=0;a<semana.length;a++) System.out.print(semana[a]+", ");
		System.out.println();
		
		System.out.println("Longitud Vector meses: "+meses.length);
		for(int a=0;a<meses.length;a++) System.out.print(meses[a]+", ");
		System.out.println();
		
		System.out.println("Longitud Vector vector: "+vector.length);
		for(int a=0;a<vector.length;a++) System.out.print(vector[a]+", ");
		System.out.println();
		
		//Error!!!
		//String[] lineas=new String[4];
		//lineas= {"a","b","c","d"};
		
		int dia=LocalDate.now().getDayOfWeek().getValue(); // 1 Lunes .... 7 Domingo
		int numeroDia=LocalDate.now().getDayOfMonth();
		int mes=LocalDate.now().getMonthValue();
		int year=LocalDate.now().getYear();
		System.out.println("Hoy es "+semana[dia-1]+" "+numeroDia+" de "+meses[mes-1]+" de "+year);
		
		//Totalizar y promediar un vector numerico
		int suma=0;
		for(int a=0;a<vector.length;a++) suma+=vector[a];
		System.out.println("Total: "+suma);
		
		double resultado=(double)suma/vector.length;
		
		System.out.println("Promedio: "+((double)suma/vector.length));
		
		//Busqueda de valor máximo y mínimo en un vector numerico
		
		//int[] vector= {23,26,24,39,38,65,22,29,14,17,15,27,28};
		int max=vector[0], min=vector[0];
		int iMax=0, iMin=0;
		for(int a=1;a<vector.length;a++) {
			if(max<vector[a]) {
				max=vector[a];
				iMax=a;
			}
			if(min>vector[a]) {
				min=vector[a];
				iMin=a;
			}
		}
		System.out.println("Valor Máximo: "+max+" Se encuentra en el indice: "+iMax);
		System.out.println("Valor Mínimo: "+min+" Se encuentra en el indice: "+iMin);
		
		{
			//Bloque de software - Ambito(Scope) de software
			int t=3;
			System.out.println(t);
		}
		//System.out.println(t);	//error
		
		for(int a=1;a<=10;a++){
			//Bloque de software - Ambito(Scope) de software
			int t=3;
			System.out.println(t);
		}
		//System.out.println(t);	//error
		
		x=1;
		while(x<=10){
			//Bloque de software - Ambito(Scope) de software
			int t=3;
			System.out.println(t);
			x++;
		}
		//System.out.println(t);	//error
		
		if(true){
			//Bloque de software - Ambito(Scope) de software
			int t=3;
			System.out.println(t);
		}
		//System.out.println(t);	//error
		
		
		
		//Contar Cantidad de números Pares
		//Contar Cantidad de números Impares
		//Contar Cantidad de veces que se repite el numero 38.
		
		//Copiar Arrays
		
		//Ordenar un Vector
		
		//Laboratorio Login
		
		System.out.println("Fin del programa!");
	}

}
