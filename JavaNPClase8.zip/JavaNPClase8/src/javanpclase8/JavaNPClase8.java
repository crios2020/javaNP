package javanpclase8;

public class JavaNPClase8 {

    public static void main(String[] args) {
        // Clase 08
        
        //llamo al formulario login
        Login.main(null);
        //Calculadora.main(null);
    }
    
}
