import java.text.DecimalFormat;

public class Clase1 {

	public static void main(String[] args) {
		
		/*
		 	Curso: Java para no programadores		15 horas
		 	Días: Martes y Viernes	11:00 a 13:00 hs
		 	Profe: Carlos Ríos	carlos.rios@educacionit.com
		 
		 	Materiales: alumni.educacionit.com	
		 				user:	email
		 				pass:	dni
		 				alumnos@educacionit.com
		 	
		 	github: https://github.com/crios2020/javaNP
		 	
		 	Software:	JDK 11 o superior
		 				(Java Development Kit)
		 				
		 	IDE: (Integrated Development Enviroment)
		 		- Eclipse for Enterprise Java and Web Developer
		 		- Netbeans IDE	https://netbeans.apache.org//
		 			
		 */
		
		// comentarios de una sola linea
		/* Bloque de comentarios */
		
		System.out.println("Hola Mundo!!");		//Imprime en consola
		
		//Lenguaje es case sensitive
		// ; es el terminador de sentencias
		// F11 para ejecutar el programa
		// " shift - 2
		// syso ctrol - espacio: atajo de teclado para System.out.println();	
		
		
		System.out.println("Hoy es Viernes");
		System.out.println("Curso Java");
		
		System.out.print("1");
		System.out.print("2");
		System.out.print("3");
		System.out.println("4");
		System.out.println("Educación IT");
		
		/*
		 	Hola Mundo!!
		 	Hoy es Viernes
		 	1234
		 	Educación IT
		 */
			
		//Variables
		//Java C++ C#.net son lenguajes de tipado fuerte
		//JavaScript, PHP, Python son lenguajes de tipado debil
		
		//Tipo de datos enteros	int
		
		//declaro una variable de tipo int
		int a; 	//declaro la variable
		a=2;	//asigno un valor a la variable
		
		//a="hola";	//error no respeta el tipo de datos de la variable
		
		//Una variable solo puede tener una declaración,
		//pero puede tener infinitas asignaciones de valor
		//int a; //error no se puede volver a declarar a
		
		a=5;
		a=8;
		a=3;
		
		int b=4;	//declaración y asignación de valor
		
		int c=a+b;	// 7
		
		int d=23, e=26, f=29, g=39, h=38;
		//declaración y asignación multiple
		
		System.out.println(a);
		System.out.println("Variable a="+a);
		System.out.println("a+b="+a+b); 		//a+b=34	//error
		System.out.println("a+b="+c); 			//a+b=7
		System.out.println("a+b="+(a+b));	 	//a+b=7
		
		//Tipo de datos String (cadena de texto)
		String p="Perro";
		String l="ladra";
		
		System.out.println(p+l); 			//Perroladra
		System.out.println(p+" "+l); 		//Perro ladra
		System.out.println(p+" que "+l); 	//Perro que ladra
		
		//Tipo de datos float 32 bits
		float fl=9.35f;
		System.out.println(fl);
		
		//Tipo de datos double 64 bits
		double dl=9.35;
		System.out.println(dl);
		
		fl=100;
		dl=100;
		
		System.out.println(fl/3);
		System.out.println(dl/3);

		//Limita la cantidad de decimales que muestra!
		// se importo(arriba de todo!) import java.text.DecimalFormat;
		System.out.println(new DecimalFormat("#.00").format(dl/3));
		
		//Tipo de datos char		unicode 2 bytes
		char x=65;
		System.out.println(x);
		x='e';
		System.out.println(x);
		
		//Tipo de datos boolean
		boolean bo=true;			//1
		bo=false;					//0
		
		System.out.println(bo);
		
	}

}
