package javanpclase7;

public class JavaNPClase7 {

    public static void main(String[] args) {
        /*
            Clase 7 Interface Gráfica (GUI Graphic User Interface).
        
        - AWT:  (Abstract Windows Type) Es la primer GUI, esta dentro del nucleo de Java,
                es la más veloz, no garantiza la misma apariencia gráfica en los distintos SOs.
        
        - Swing: (JFrame) Esta dentro del nucleo de Java, garantiza la misma apariencia en 
                todos los SOs.
        
        - JavaFx: dentro del nucleo de Java desde jdk 6 hasta el 10, 
                    respeta el patron de diseño MVC (Modelo Vista Controlador),
                    Cross Platform (multiplataforma) para apps Desktop, Mobile, Web,
                    Fracaso Comercial, fue discontinuada dentro del nucleo de java.
        
        */
        
        
        
    }
    
}
