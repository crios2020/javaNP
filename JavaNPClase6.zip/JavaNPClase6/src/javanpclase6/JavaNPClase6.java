package javanpclase6;

import java.util.Arrays;

public class JavaNPClase6 {

    public static void main(String[] args) {
        // Clase 6 Vectores - Arrays    Parte 2
        
        //sout - |tab|: atajo de teclado para System.out.println("");
        
        int[] vector= {23,26,24,39,38,65,22,29,38,14,17,15,27,28,38,17,25,29};
        
        //Contar Cantidad de números Pares
        //Contar Cantidad de números Impares
        //Contar Cantidad de veces que se repite el numero 38.
        int contPar=0, contImpar=0, cont38=0;
        for(int a=0; a<vector.length; a++){
            if(vector[a]%2==0)  contPar++;
            else                contImpar++;
            if(vector[a]==38)   cont38++;
        }
        System.out.println("Cantidad Números Pares: "+contPar);
        System.out.println("Cantidad Números Impares: "+contImpar);
        System.out.println("Cantidad Número 38: "+cont38);
        
        //Copiar Arrays
        int[] pares={2,4,6,8,10};
        int[] impares=new int[pares.length];
        int[] pares2=new int[pares.length];
        
        /*
                pares           impares         pares2
                    2            _1_             ___
                    4            _3_             ___
                    6            _5_             ___
                    8            _7_             ___
                   10            _9_             ___

        */
        
        //copiar pares a impares
        for(int a=0;a<pares.length;a++){
            impares[a]=pares[a]-1;
        }
        
        for(int a=0;a<pares.length;a++){
            System.out.println(impares[a]+" "+pares[a]);
        }
        
        //copiar vectores usando System.arraycopy
        System.arraycopy(pares, 0, pares2, 0, pares.length);
        
        for(int a=0;a<pares.length;a++){
            System.out.println(pares[a]+" "+pares2[a]);
        }
        
        //Ordenar un Vector
        for(int a=0; a<vector.length; a++) System.out.print(vector[a]+", ");
        System.out.println();

        Arrays.sort(vector);
        
        for(int a=0; a<vector.length; a++) System.out.print(vector[a]+", ");
        System.out.println();
           
        String[] semana= {"Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"};
	String[] meses= {"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};
        
        //Arrays.sort(semana);
        //Arrays.sort(meses);
        
        //for(int a=0;a<semana.length;a++) System.out.println(semana[a]);
        //for(int a=0;a<meses.length;a++) System.out.println(meses[a]);
        
        //for(int a=semana.length-1;a>=0;a--) System.out.println(semana[a]);
        //for(int a=meses.length-1;a>=0;a--)  System.out.println(meses[a]);
        
        //Recorrido forEach         jdk 5 o sup.
        for(int n:vector)       System.out.println(n);
        for(String d:semana)    System.out.println(d);
        for(String m:meses)     System.out.println(m);
       
        //Laboratorio Login
           
        
                
    }
    
}
