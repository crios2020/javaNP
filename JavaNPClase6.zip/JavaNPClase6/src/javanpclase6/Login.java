package javanpclase6;

import java.time.LocalDate;
import java.util.Scanner;

public class Login {

    public static void main(String[] args) {
        String black = "\033[30m";
        String red = "\033[31m";
        String green = "\033[32m";
        String yellow = "\033[33m";
        String blue = "\033[34m";
        String purple = "\033[35m";
        String cyan = "\033[36m";
        String white = "\033[37m";
        String reset = "\u001B[0m";

        String[] semana= {"Lunes","Martes","Miércoles","Jueves","Viernes","Sábado","Domingo"};
		String[] meses= {"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"};

        String[] users      = {"Juan" , "Ana" , "Maria" , "Jose" };
        String[] passwords  = {"123"  , "321" , "abc"   , "111"  };

        String user;
        String pass;
        if(args.length!=2){
            System.out.println(green);
            System.out.println("*****************************************************************");
            System.out.println("*                    Inicio de Sessión                          *");
            System.out.println("*****************************************************************");
            System.out.println(blue);
            System.out.print("Ingrese su nombre de usuario: ");
            user = new Scanner(System.in).next();
            System.out.println();
            System.out.print("Ingrese su clave: ");
            pass = new Scanner(System.in).next();
            System.out.println(reset);
        } else {
            user=args[0];
            pass=args[1];
        }
        //System.out.println(user+" "+pass);
        //System.out.println(user=="root");
        //System.out.println(user.equals("root"));

        boolean existe=false;
        int donde=0;

        for(int a=0; a<users.length;a++){
            if(users[a].equals(user)){
                existe=true;
                donde=a;
            }
        }

        //System.out.println(existe+" "+donde);
        if(existe){
            if(pass.equals(passwords[donde])){
                System.out.println(green+"Bienvenido "+user+"!"+reset);
                int dia=LocalDate.now().getDayOfWeek().getValue(); // 1 Lunes .... 7 Domingo
                int numeroDia=LocalDate.now().getDayOfMonth();
                int mes=LocalDate.now().getMonthValue();
                int year=LocalDate.now().getYear();
                System.out.println("Hoy es "+semana[dia-1]+" "+numeroDia+" de "+meses[mes-1]+" de "+year);   
            }else{
                System.out.println(red+"Clave Incorrecta!"+reset);
            }
        } else {
            System.out.println(red+"El usuario "+user+" no exite!"+reset);
        }

    }
}
