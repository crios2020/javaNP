import java.time.LocalDate;

public class Clase3 {

	public static void main(String[] args) {
		// Estructura Switch
		
		// dia de la semana 1 - Lunes ....... 7 - Domingo
		int dia=LocalDate.now().getDayOfWeek().getValue();
		//dia=25;
		System.out.println(dia);

//		if(dia==1) System.out.println("Lunes");
//		if(dia==2) System.out.println("Martes");
//		if(dia==3) System.out.println("Miércoles");
//		if(dia==4) System.out.println("Jueves");
//		if(dia==5) System.out.println("Viernes");
//		if(dia==6) System.out.println("Sábado");
//		if(dia==7) System.out.println("Domingo");
		
		switch(dia) {
			case 1: System.out.println("Lunes"); 	break;
			case 2: System.out.println("Martes"); 	break;
			case 3: System.out.println("Miércoles");break;
			case 4: System.out.println("Jueves"); 	break;
			case 5: System.out.println("Viernes"); 	break;
			case 6: System.out.println("Sábado"); 	break;
			case 7: System.out.println("Domingo"); 	break;
			default: System.out.println("Error!");
		}
		
		switch(dia) {
			case 1: case 2: case 3: case 4: case 5: 
				System.out.println("Hoy es dia laboral");
			break;
			case 6: case 7: 
				System.out.println("Fin de semana!");
			break;
			default: System.out.println("Error!");
		}
		
		switch(dia) {
			case 1: System.out.println("Lunes");
			case 2: System.out.println("Martes");
			case 3: System.out.println("Miércoles");
			case 4: System.out.println("Jueves");
			case 5: System.out.println("Viernes");
			case 6: case 7: 
				System.out.println("Fin de semana!");
			break;
			default: System.out.println("Error!");
		}
		
		int numDia=LocalDate.now().getDayOfYear();
		System.out.println(numDia);
		int numVerano=LocalDate.of(2021, 12, 21).getDayOfYear();
		System.out.println(numVerano);
		System.out.println("Faltan "+(numVerano-numDia)+" días para el Verano!!");
		
		//Estructura While (mientras)
		int a=20;
		System.out.println("-- Inicio de estructura While --");
		while(a<=10) {
			System.out.println(a);
			a++;
			//duerme 1 s
			//try {Thread.sleep(1000);} catch(Exception e) {}
		}
		System.out.println("-- Fin de esctructura While --");
		System.out.println(a);
		
		//Estructora Do While 
		a=20;
		System.out.println("-- Inicio de esctructura Do While --");
		do {
			System.out.println(a);
			a++;
		}while(a<=10);
		System.out.println("-- Fin de estructura Do While --");
		System.out.println(a);
		
		//Modo de uso de llaves expandido
		a=1;
		while(a<=10)
		{
			System.out.println(a);
			a++;
		}
		
		//Modo Abreviado
		a=1;
		while(a<=10) System.out.println(a++);
		
		//Pendiente loop infinito
		
	}

}
