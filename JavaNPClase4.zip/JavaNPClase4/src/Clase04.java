import java.text.DecimalFormat;
import java.time.LocalTime;

public class Clase04 {

	public static void main(String[] args) {
		// Clase 4
		int a;

		// Loop Infinito
//		a=1;
//		while(true) {
//			System.out.println(a);
//			a++;
//		}

		// Loop Infinito
//		a=1;
//		while(a<=10 || true) {
//			System.out.println(a);
//			a++;
//		}

		// Loop Infinito
//		a=1;
//		while(a<=10 || a>=10) {
//			System.out.println(a);
//			a++;
//		}

		// Loop Infinito
//		a=1;
//		while(a<=10) {
//			System.out.println(a--);
//			a++;
//		}

		// Loop Infinito
//		a=1;
//		while(a<=10);
//		{
//			System.out.println(a);
//			a++;
//		}

		// Estructura while
		a = 1;
		System.out.println("-- Inicio de estructura while --");
		while (a <= 10) {
			System.out.println(a);
			a++;
		}
		System.out.println("-- Fin de estructura while --");
		System.out.println(a);

		// Estructura For
		System.out.println("-- Inicio de estructura for --");
		for (int x = 1; x <= 10; x++) {
			System.out.println(x);
		}
		System.out.println("-- Fin de esctructura for --");
		// System.out.println(x); //error, variable fuera de scope

		// Modo de llaves expandido
		for (int x = 1; x <= 10; x++) {
			System.out.println(x);
		}

		// Modo de llaves abreviado
		for (int x = 1; x <= 10; x++)
			System.out.println(x);

		// Tabla de caracteres
		for (int x = 32; x <= 255; x++) {
			if (x < 127 || x > 159)
				System.out.println(x + "\t" + (char) x);
		}

		// Recorrido con variable global
		System.out.println("**************************************");
		for (a = 1; a <= 10; a++) {
			System.out.println(a);
		}
		System.out.println("**************************************");
		System.out.println(a);
		System.out.println("**************************************");
		for (a++; a <= 20; a++) {
			System.out.println(a);
		}
		System.out.println("**************************************");
		for (; a <= 30; a++) {
			System.out.println(a);
		}

		System.out.println("**************************************");
		// Sentencia break y continue
		for (int x = 0; x <= 20; x += 2) {
			if (x == 10 || x == 12)
				continue;
			System.out.println(x);
			if (x == 16)
				break;
		}

		for (int x = 0; x <= 16; x += 2) {
			if (x != 10 || x != 12)
				System.out.println(x);
		}
		System.out.println("**************************************");

		// Recorrido for con multiples variables de control
		for (int r = 1, s = 1; r <= 5 && s <= 10; r++, s++) {
			System.out.println(r + " " + s);
		}
		System.out.println("**************************************");
		for (int r = 1, s = 1; r <= 5 || s <= 10; r++, s++) {
			System.out.println(r + " " + s);
		}

		System.out.println("**************************************");

		// Omisión de parametros
		a = 1;
		for (;;) {
			System.out.println(a++);
			if (a > 10)
				break;
		}

		// For anidado
		int cont = 0;
		for (int x = 1; x <= 10; x++) {
			for (int r = 1; r <= 10; r++) {
				for (int s = 1; s <= 10; s++) {
					cont++;
					System.out.println(x + " " + r + " " + s + " " + cont);
				}
			}
		}

		DecimalFormat df=new DecimalFormat("00");
		
		// Horas del día
//		for(int hora=0;hora<24;hora++) {
//			for(int minuto=0;minuto<60;minuto++) {
//				for(int segundo=0;segundo<60;segundo++) {
//					System.out.println(df.format(hora)+":"+df.format(minuto)+":"+df.format(segundo));
//					try {Thread.sleep(1000);} catch(Exception e) {}
//				}
//			}
//		}
		
		
		LocalTime lt=LocalTime.now();
//		for(int hora=lt.getHour();hora<24;hora++) {
//			for(int minuto=lt.getMinute();minuto<60;minuto++) {
//				for(int segundo=lt.getSecond();segundo<60;segundo++) {
//					System.out.println(df.format(hora)+":"+df.format(minuto)+":"+df.format(segundo));
//					try {Thread.sleep(1000);} catch(Exception e) {}
//				}
//			}
//		}
		
		//loop infinito
		//for(int x=1;true;x++) System.out.println(x);

		//loop infinito
		//for(int x=1;;x++) System.out.println(x);
		
		//loop infinito
		//for(int x=1;x<=10 || true;x++) System.out.println(x);
		
		//loop infinito
		//for(int x=1;x<=10 || x>=1;x++) System.out.println(x);
		
		//loop infinito
//		for(int x=1;x<=10;x++) {
//			System.out.println(x);
//			if(x==5) x-=2;
//		}
		
		//loop infinito
//		a=3;
//		for(int x=a;a<=10;x++) System.out.println(x);
		
		//loop infinito
//		a=3;
//		for(int x=a;x<=10;a++) System.out.println(x);
		
		//Sumar numeros del 1 al 20
		int suma=0;
		for(int x=1;x<=20;x++) suma+=x;
		System.out.println("Total: "+suma);
		
		//Operador Resto %
		System.out.println(15%2);				// 1
		System.out.println(14%2);				// 0
		System.out.println(-14%2);				// 0
		System.out.println(-15%2);				//-1
		
		//Sumar numeros pares del 1 al 20
		suma=0;
		for(int x=1;x<=20;x++) {
			if(x%2==0) suma+=x;
		}
		System.out.println("Total: "+suma);
		
		
		//Continuar con Arrays
		
		
	}

}
